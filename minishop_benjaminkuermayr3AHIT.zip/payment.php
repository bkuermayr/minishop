<?php 
include('./forms/credit.php');
?>