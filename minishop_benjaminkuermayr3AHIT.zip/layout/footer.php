<footer class="bg-light py-4 container-fluid">
        <div class="container">
            <div class="row">
            <div class="col-md-6 col-sm-12">
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="?pageid=impressum">Impressum</a></li>
                    <li class="list-inline-item"><a href="?pageid=sitemap">Sitemap</a></li>
                </ul>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <p>&copy; Shoppolini - Der Online-Shop 2020</p>
            </div>
            </div>
        </div>

    </footer>
    <script src="dependencies/js/jquery-3.3.1.min.js"></script>
    <script src="dependencies/js/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="dependencies/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="./js/scripts.js"></script>
</body>
</html>