<?php 
    echo orderMail('test@wd.com');
?>
